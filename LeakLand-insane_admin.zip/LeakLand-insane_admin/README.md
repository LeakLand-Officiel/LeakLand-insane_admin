# Insane Admin V1

Discord Five-Dev : https://discord.gg/pRXCnA8


Admin menu complet fait en RageUI.
90% du système report fait et aider par @h4ci


